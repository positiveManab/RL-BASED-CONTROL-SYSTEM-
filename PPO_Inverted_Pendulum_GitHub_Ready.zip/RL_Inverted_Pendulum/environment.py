"""Cart-pole swing-up environment (vectorised: many simulations in parallel)."""
import numpy as np
import config as C
from physics import CartPole


def wrap_angle(th):
    return (th + np.pi) % (2 * np.pi) - np.pi


class CartPoleEnv:
    obs_dim = 5
    act_dim = 1

    def __init__(self, num_envs=1, seed=None):
        self.n = num_envs
        self.sim = CartPole(num_envs)
        self.rng = np.random.default_rng(seed)
        self.steps = np.zeros(num_envs, dtype=int)
        self.prev_action = np.zeros(num_envs)
        self.time = np.zeros(num_envs)
        self.last_force = np.zeros(num_envs)

    @property
    def state(self):
        return self.sim.state

    @staticmethod
    def observe(state):
        x, x_dot, th, th_dot = state.T
        return np.stack([x / C.TRACK_LIMIT, x_dot / 3.0, np.cos(th), np.sin(th),
                         th_dot / 8.0], axis=1).astype(np.float32)

    def _random_states(self, k):
        """Training starts: mostly hanging down, some random, some near upright."""
        u = self.rng.random(k)
        th = np.where(u < 0.5, np.pi + self.rng.normal(0, 0.3, k),
                      np.where(u < 0.75, self.rng.uniform(-np.pi, np.pi, k),
                               self.rng.normal(0, 0.15, k)))
        return np.stack([self.rng.uniform(-0.5, 0.5, k), np.zeros(k), th,
                         self.rng.normal(0, 0.2, k)], axis=1)

    def reset(self, theta0=None):
        """Full reset. theta0 (rad) -> single deterministic start (demo);
        None -> random training starts."""
        if theta0 is not None:
            states = np.array([[0.0, 0.0, theta0, 0.0]] * self.n)
        else:
            states = self._random_states(self.n)
        self.sim.reset(states)
        self.steps[:] = 0
        self.prev_action[:] = 0.0
        self.time[:] = 0.0
        self.last_force[:] = 0.0
        return self.observe(self.sim.state)

    def reset_idx(self, mask):
        """Reset only the finished environments (training)."""
        k = int(mask.sum())
        if k:
            self.sim.state[mask] = self._random_states(k)
            self.steps[mask] = 0
            self.prev_action[mask] = 0.0
            self.time[mask] = 0.0
        return self.observe(self.sim.state)

    def step(self, action):
        """action in [-1, 1], shape (n,) or (n,1). Returns obs, reward, truncated."""
        a = np.clip(np.asarray(action, dtype=np.float64).reshape(self.n), -1.0, 1.0)
        self.last_force = a * C.MAX_FORCE
        x, x_dot, th, th_dot = self.sim.step(self.last_force).T
        self.steps += 1
        self.time += C.DT

        thw = wrap_angle(th)
        reward = (-0.1 * thw ** 2 - 0.002 * th_dot ** 2 + np.exp(-thw ** 2 / 0.1)
                  - 0.05 * x ** 2 - 0.01 * a ** 2 - 0.02 * (a - self.prev_action) ** 2
                  - 3.0 * np.clip((np.abs(x) - 1.6) / 0.8, 0.0, None) ** 2
                  - 10.0 * self.sim.hit_wall) * C.REWARD_SCALE
        self.prev_action = a
        truncated = self.steps >= C.MAX_EPISODE_STEPS
        return self.observe(self.sim.state), reward, truncated
