"""Central configuration for the RL inverted pendulum (swing-up + balance)."""
import math
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "trained_model.pth"

# ---------------- Physics (SI units) ----------------
GRAVITY = 9.81
CART_MASS = 1.0            # kg
POLE_MASS = 0.2            # kg
POLE_HALF_LENGTH = 0.5     # m  (pivot -> centre of mass; full pole = 1.0 m)
CART_FRICTION = 0.1        # N*s/m   viscous friction of cart on track
PIVOT_DAMPING = 0.005      # N*m*s/rad  friction in the pole hinge
MAX_FORCE = 15.0           # N   actuator saturation
TRACK_LIMIT = 2.4          # m   cart centre limit (inelastic end stops)

DT = 0.02                  # s   control period (50 Hz)
PHYSICS_SUBSTEPS = 5       # RK4 sub-steps per control period

# ---------------- Environment ----------------
MAX_EPISODE_STEPS = 1000   # 20 s per training episode
REWARD_SCALE = 0.1

# ---------------- PPO ----------------
HIDDEN_SIZE = 128
LEARNING_RATE = 3e-4
GAMMA = 0.995
GAE_LAMBDA = 0.95
CLIP_EPS = 0.2
VALUE_COEF = 0.5
ENTROPY_COEF = 0.0
MAX_GRAD_NORM = 0.5
NUM_ENVS = 64              # parallel simulations (vectorised in numpy)
ROLLOUT_STEPS = 128        # steps per env per update
PPO_EPOCHS = 10
MINIBATCH_SIZE = 1024
TOTAL_UPDATES = 700
SEED = 1

# ---------------- Demo ----------------
DEMO_INITIAL_ANGLE_DEG = 180.0   # 180 = hanging straight down, 0 = upright
