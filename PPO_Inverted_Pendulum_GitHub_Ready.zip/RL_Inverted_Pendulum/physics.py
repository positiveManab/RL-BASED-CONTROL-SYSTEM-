"""Nonlinear cart-pole dynamics (cart with viscous friction, damped hinge).
Vectorised: state has shape (n, 4) = [x, x_dot, theta, theta_dot].
theta = 0 is upright, theta = pi is hanging down; positive leans toward +x."""
import numpy as np
import config as C


class CartPole:
    def __init__(self, n=1):
        self.state = np.zeros((n, 4))
        self.hit_wall = np.zeros(n, dtype=bool)

    def reset(self, state):
        self.state = np.array(state, dtype=np.float64).reshape(-1, 4)
        return self.state

    @staticmethod
    def derivatives(s, force):
        x_dot, th, th_dot = s[:, 1], s[:, 2], s[:, 3]
        M, m, l = C.CART_MASS, C.POLE_MASS, C.POLE_HALF_LENGTH
        inertia = m * l * l / 3.0          # uniform rod about its centre
        sin_t, cos_t = np.sin(th), np.cos(th)

        a, b = M + m, m * l * cos_t
        d = inertia + m * l * l
        rhs1 = force - C.CART_FRICTION * x_dot + m * l * th_dot ** 2 * sin_t
        rhs2 = m * C.GRAVITY * l * sin_t - C.PIVOT_DAMPING * th_dot
        det = a * d - b * b
        x_dd = (rhs1 * d - b * rhs2) / det
        th_dd = (a * rhs2 - b * rhs1) / det
        return np.stack([x_dot, x_dd, th_dot, th_dd], axis=1)

    def step(self, force):
        """Advance one control period (RK4 sub-steps). force: shape (n,)."""
        force = np.clip(np.asarray(force, dtype=np.float64), -C.MAX_FORCE, C.MAX_FORCE)
        h = C.DT / C.PHYSICS_SUBSTEPS
        s = self.state
        self.hit_wall = np.zeros(s.shape[0], dtype=bool)
        L = C.TRACK_LIMIT
        for _ in range(C.PHYSICS_SUBSTEPS):
            k1 = self.derivatives(s, force)
            k2 = self.derivatives(s + 0.5 * h * k1, force)
            k3 = self.derivatives(s + 0.5 * h * k2, force)
            k4 = self.derivatives(s + h * k3, force)
            s = s + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
            right, left = s[:, 0] > L, s[:, 0] < -L      # inelastic end stops
            s[right, 0], s[right, 1] = L, np.minimum(s[right, 1], 0.0)
            s[left, 0], s[left, 1] = -L, np.maximum(s[left, 1], 0.0)
            self.hit_wall |= right | left
        self.state = s
        return s
