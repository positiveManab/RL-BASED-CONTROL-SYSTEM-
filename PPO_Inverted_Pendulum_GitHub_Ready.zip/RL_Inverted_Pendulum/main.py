"""Load the trained PPO controller and run the swing-up + balance simulation."""
import sys
import config as C
from agent import PPOAgent
from environment import CartPoleEnv
from visualize import Visualizer


def main():
    if not C.MODEL_PATH.exists():
        sys.exit(f"Trained model not found: {C.MODEL_PATH}")
    agent = PPOAgent.load(C.MODEL_PATH)
    env = CartPoleEnv()
    Visualizer(env, agent, C.DEMO_INITIAL_ANGLE_DEG).run()


if __name__ == "__main__":
    main()
