# PPO-Based Inverted Pendulum Controller

> A reinforcement-learning controller that learns to **swing a pendulum from the hanging position to the upright position and then balance it**, using Proximal Policy Optimization (PPO).

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![PyTorch](https://img.shields.io/badge/PyTorch-2.2%2B-orange)
![RL](https://img.shields.io/badge/Reinforcement%20Learning-PPO-green)
![Control](https://img.shields.io/badge/Control-Continuous%20Force-purple)

## Project Overview

This project implements a custom **cart-pole / inverted-pendulum environment** and a **PPO actor-critic controller** in PyTorch.

The objective is not simply to keep an already-upright pole balanced. The controller must learn the harder sequence:

**Hanging pendulum → Swing-up → Upright position → Balance**

A pretrained model is included in `models/trained_model.pth`, so the project can be run directly without retraining.

## Demo

Run the project and a real-time Matplotlib animation will show:

- cart movement
- pendulum swing-up
- upright reference position
- pole angle
- cart position
- applied control force
- simulation time

> **Recommended GitHub improvement:** add a short GIF of the successful swing-up here as `docs/demo.gif`.

## Why PPO?

PPO is a policy-gradient reinforcement-learning algorithm designed to make stable policy updates.

In this project, PPO is useful because the controller produces a **continuous control signal** rather than choosing from a small list of discrete actions.

The policy learns:

> **Observation → Continuous control force**

instead of:

> Observation → left/right discrete action

---

## System Architecture

```text
                 ┌─────────────────────────┐
                 │   Cart-Pole Environment  │
                 │  Nonlinear Physics Model │
                 └────────────┬────────────┘
                              │
                              ▼
                    5-D Observation
              [x, x_dot, cos(theta),
               sin(theta), theta_dot]
                              │
                              ▼
                 ┌─────────────────────────┐
                 │       PPO Actor          │
                 │  5 → 128 → 128 → 1      │
                 │       Tanh hidden        │
                 └────────────┬────────────┘
                              │
                              ▼
                    Continuous Action
                       [-1, +1]
                              │
                              ▼
                    Force = action × 15 N
                              │
                              ▼
                 ┌─────────────────────────┐
                 │     Cart-Pole Physics   │
                 │       RK4 integration   │
                 └────────────┬────────────┘
                              │
                              └──────► next state
```

The PPO critic uses a separate network with the same hidden-layer structure:

```text
Observation (5)
      ↓
Linear(5 → 128) + Tanh
      ↓
Linear(128 → 128) + Tanh
      ↓
Linear(128 → 1)
      ↓
State Value V(s)
```

---

## Environment

The simulation uses a custom nonlinear cart-pole model.

### Physical parameters

| Parameter | Value |
|---|---:|
| Gravity | 9.81 m/s² |
| Cart mass | 1.0 kg |
| Pole mass | 0.2 kg |
| Pole half-length | 0.5 m |
| Full pole length | 1.0 m |
| Cart friction | 0.1 N·s/m |
| Pivot damping | 0.005 N·m·s/rad |
| Maximum force | ±15 N |
| Track limit | ±2.4 m |
| Control period | 0.02 s |
| Physics substeps | 5 |
| Integration | RK4 |

The physics are implemented in `physics.py`.

---

## State / Observation Space

The raw physical state is:

```text
[x, x_dot, theta, theta_dot]
```

The RL agent receives a normalized **5-dimensional observation**:

```text
[
    x / track_limit,
    x_dot / 3,
    cos(theta),
    sin(theta),
    theta_dot / 8
]
```

Using `sin(theta)` and `cos(theta)` avoids the discontinuity that occurs when an angle wraps from `+π` to `-π`.

### Meaning

| Observation | Meaning |
|---|---|
| `x` | Cart position |
| `x_dot` | Cart velocity |
| `cos(theta)` | Pole orientation |
| `sin(theta)` | Pole orientation |
| `theta_dot` | Angular velocity |

---

## Action Space

The PPO policy outputs one continuous action:

```text
a ∈ [-1, +1]
```

This is converted into actuator force:

```text
force = action × 15 N
```

Therefore the controller can apply any force between approximately:

```text
-15 N ≤ force ≤ +15 N
```

---

## Reward Function

The reward is designed to encourage upright balancing while discouraging unstable or inefficient behavior.

The implementation combines penalties/rewards for:

- pole angle error
- angular velocity
- upright proximity
- cart position
- excessive control effort
- sudden changes in action
- approaching the track boundary
- hitting the track end stop

The implemented reward is:

```text
reward = (
    -0.1 * theta_error²
    -0.002 * angular_velocity²
    + exp(-theta_error² / 0.1)
    -0.05 * cart_position²
    -0.01 * action²
    -0.02 * action_change²
    - boundary_penalty
    - wall_penalty
) × 0.1
```

This gives the agent a strong incentive to reach and maintain the upright state while keeping the cart controlled.

---

## PPO Configuration

| Hyperparameter | Value |
|---|---:|
| Algorithm | PPO |
| Hidden size | 128 |
| Hidden layers | 2 |
| Activation | Tanh |
| Learning rate | 3 × 10⁻⁴ |
| Discount factor γ | 0.995 |
| GAE λ | 0.95 |
| PPO clip ε | 0.2 |
| Value coefficient | 0.5 |
| Entropy coefficient | 0.0 |
| Gradient clipping | 0.5 |
| Parallel environments | 64 |
| Rollout steps | 128 |
| PPO epochs/update | 10 |
| Minibatch size | 1024 |
| Total updates | 700 |
| Random seed | 1 |

### Network size

The actor and critic each use:

```text
5 → 128 → 128 → 1
```

The checkpoint contains **34,819 trainable parameters** in total, including the actor, critic, and learnable action-distribution log standard deviation.

---

## Training Strategy

Training uses **64 parallel environments** to collect experience efficiently.

Each update collects:

```text
64 environments × 128 steps
= 8,192 transitions/update
```

Across 700 updates, this corresponds to approximately:

```text
8,192 × 700
= 5,734,400 transitions
```

The environment uses randomized initial conditions during training:

- mostly hanging-down states
- random angular states
- some near-upright states
- randomized cart positions and angular velocities

This helps the policy generalize beyond a single starting configuration.

---

## Pretrained Model

A trained PyTorch checkpoint is already included:

```text
models/trained_model.pth
```

The normal demo therefore **does not require training**.

`main.py` loads the saved PPO policy and starts the visualization.

---

## Installation

### 1. Clone the repository

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd RL_Inverted_Pendulum
```

### 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```powershell
pip install -r requirements.txt
```

---

## Run the Trained Controller

```powershell
python main.py
```

A Matplotlib window should open and show the trained controller operating the cart-pole.

The demo starts from:

```text
180°
```

In this project:

```text
0°   = upright
180° = hanging down
```

So the controller must first **swing the pole upward** and then **stabilize it around 0°**.

---

## Retrain the Controller

The PPO implementation and training loop are contained in:

```text
agent.py
```

To train from scratch:

```powershell
python agent.py
```

The trained checkpoint is saved to:

```text
models/trained_model.pth
```

> Training is much more computationally expensive than running the included pretrained model. For demonstration purposes, use `python main.py`.

---

## Project Structure

```text
RL_Inverted_Pendulum/
│
├── main.py                 # Loads the trained PPO model and runs demo
├── agent.py                # PPO actor-critic + training algorithm
├── environment.py          # RL environment and reward function
├── physics.py              # Nonlinear cart-pole dynamics + RK4
├── visualize.py            # Real-time Matplotlib animation
├── config.py               # Physics and PPO hyperparameters
├── requirements.txt        # Python dependencies
│
├── models/
│   └── trained_model.pth   # Pretrained PPO checkpoint
│
└── docs/
    └── PROJECT_DETAILS.md  # Detailed technical/viva reference
```

---

## Key Technical Features

- Custom nonlinear cart-pole physics
- Continuous-force control
- PPO actor-critic architecture
- Generalized Advantage Estimation (GAE)
- PPO clipped surrogate objective
- Parallel environment rollouts
- RK4 numerical integration
- Randomized training initial states
- Action and state normalization
- Gradient clipping
- Learning-rate scheduling
- Deterministic inference mode
- Real-time visualization

---

## What Makes This Different From Basic CartPole

Many introductory reinforcement-learning examples use a simplified discrete-action environment.

This project instead implements:

1. **Custom physics**
2. **Continuous force control**
3. **Swing-up from the hanging state**
4. **Balance around the unstable upright state**
5. **Parallel simulation during training**
6. **A PPO actor-critic implementation**
7. **A real-time custom visualization**

That makes it suitable as a reinforcement-learning/control-systems project rather than only a library demonstration.

---

## PPO in Simple Terms

PPO repeatedly improves a policy while limiting how much the policy is allowed to change in one update.

The basic idea is:

```text
Collect experience
       ↓
Estimate advantage
       ↓
Compare new policy with old policy
       ↓
Clip excessively large policy changes
       ↓
Update actor + critic
       ↓
Repeat
```

The actor learns **what force to apply**.

The critic learns **how good the current state is**.

---

## Project Files at a Glance

| File | Purpose |
|---|---|
| `main.py` | Runs the pretrained controller |
| `agent.py` | PPO implementation and training |
| `environment.py` | Observation, reward, reset and step logic |
| `physics.py` | Cart-pole dynamics |
| `visualize.py` | Simulation animation |
| `config.py` | All major parameters |
| `trained_model.pth` | Saved trained model |

---

## Future Improvements

Possible extensions include:

- Add training/reward curves
- Compare PPO with DDPG, SAC or TD3
- Add disturbance rejection tests
- Test different cart/pole masses
- Add noise to sensor observations
- Benchmark settling time and overshoot
- Add automatic evaluation statistics
- Export a short demonstration GIF
- Add a web-based interactive visualization
- Compare learned control with a classical controller such as LQR

---

## Learning Outcomes

This project demonstrates practical understanding of:

- Reinforcement learning
- PPO
- Actor-critic methods
- Continuous control
- Reward engineering
- GAE
- Policy optimization
- Neural-network function approximation
- Nonlinear system simulation
- Numerical integration
- Control-system visualization

---

## Author

**Manab**

Reinforcement Learning / Intelligent Control Project

Academic Year: **2026–27**

---

## License

This project is intended for educational and academic use.
