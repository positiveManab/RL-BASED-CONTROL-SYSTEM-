"""Real-time matplotlib animation: RL agent swings the pole up and balances it."""
import math
import time
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import Rectangle, Circle
import config as C

# drawing geometry (metres)
WHEEL_R = 0.07
CART_W, CART_H = 0.50, 0.20
BODY_BOTTOM = 2 * WHEEL_R * 0.8 + 0.01
PIVOT_Y = BODY_BOTTOM + CART_H / 2
POLE_LEN = 2 * C.POLE_HALF_LENGTH
WHEEL_DX = CART_W * 0.30
START_DELAY = 1.0   # seconds to show the initial pose before control starts


class Visualizer:
    def __init__(self, env, agent, initial_angle_deg):
        self.env, self.agent = env, agent
        self.obs = env.reset(math.radians(initial_angle_deg))[0]
        self.t_start = None

        plt.rcParams["toolbar"] = "None"
        self.fig, self.ax = plt.subplots(figsize=(12, 6.4))
        self.fig.canvas.manager.set_window_title("RL Inverted Pendulum (PPO)")
        self._build_scene()

    # ---------------- static + dynamic artists ----------------
    def _build_scene(self):
        ax, L = self.ax, C.TRACK_LIMIT
        ax.set_xlim(-L - 0.7, L + 0.7)
        ax.set_ylim(-1.25, 1.9)
        ax.set_aspect("equal")
        ax.set_facecolor("#f7f9fc")
        ax.set_yticks([])
        ax.set_xlabel("position (m)")
        for s in ("left", "right", "top"):
            ax.spines[s].set_visible(False)

        # track: rail, end stops, ticks
        ax.plot([-L - CART_W / 2, L + CART_W / 2], [0, 0], color="#37474f", lw=4, zorder=1)
        for sgn in (-1, 1):
            ax.add_patch(Rectangle((sgn * (L + CART_W / 2) - 0.04, 0), 0.08, 0.22,
                                   color="#b71c1c", zorder=1))
        for tx in [i * 0.5 for i in range(-4, 5)]:
            ax.plot([tx, tx], [0, -0.06], color="#37474f", lw=1)
            ax.text(tx, -0.12, f"{tx:g}", ha="center", va="top", fontsize=8, color="#546e7a")

        # upright reference
        self.ref, = ax.plot([0, 0], [PIVOT_Y, PIVOT_Y + POLE_LEN * 1.15], ls="--",
                            color="#2e7d32", lw=1.5, zorder=2)
        self.ref_label = ax.text(0, PIVOT_Y + POLE_LEN * 1.15 + 0.03, "upright (0°)",
                                 ha="center", va="bottom", fontsize=9, color="#2e7d32")

        # cart, wheels, spokes
        self.cart = Rectangle((0, BODY_BOTTOM), CART_W, CART_H, fc="#1565c0",
                              ec="#0d47a1", lw=1.5, zorder=3)
        ax.add_patch(self.cart)
        self.wheels = [Circle((0, WHEEL_R), WHEEL_R, fc="#263238", ec="black", zorder=4)
                       for _ in range(2)]
        self.spokes = [[ax.plot([], [], color="#cfd8dc", lw=1.5, zorder=5)[0]
                        for _ in range(2)] for _ in range(2)]
        for w in self.wheels:
            ax.add_patch(w)

        # pendulum
        self.pole, = ax.plot([], [], color="#ef6c00", lw=6, solid_capstyle="round", zorder=6)
        self.bob = Circle((0, 0), 0.07, fc="#e65100", ec="#bf360c", zorder=7)
        ax.add_patch(self.bob)
        self.pivot = Circle((0, PIVOT_Y), 0.025, fc="white", ec="black", zorder=8)
        ax.add_patch(self.pivot)

        # readout
        self.hud = ax.text(0.01, 0.98, "", transform=ax.transAxes, va="top", ha="left",
                           family="monospace", fontsize=11,
                           bbox=dict(boxstyle="round", fc="white", ec="#b0bec5", alpha=0.9))
        self.artists = ([self.ref, self.ref_label, self.cart, self.pole, self.bob,
                         self.pivot, self.hud] + self.wheels
                        + [s for pair in self.spokes for s in pair])

    # ---------------- drawing ----------------
    def _draw(self):
        x, _, th, _ = self.env.state[0]
        self.cart.set_x(x - CART_W / 2)
        for i, off in enumerate((-WHEEL_DX, WHEEL_DX)):
            cx = x + off
            self.wheels[i].center = (cx, WHEEL_R)
            phi = -x / WHEEL_R                      # rolling without slipping
            for k, sp in enumerate(self.spokes[i]):
                a = phi + k * math.pi / 2
                dx, dy = WHEEL_R * 0.9 * math.cos(a), WHEEL_R * 0.9 * math.sin(a)
                sp.set_data([cx - dx, cx + dx], [WHEEL_R - dy, WHEEL_R + dy])
        tip = (x + POLE_LEN * math.sin(th), PIVOT_Y + POLE_LEN * math.cos(th))
        self.pole.set_data([x, tip[0]], [PIVOT_Y, tip[1]])
        self.bob.center = tip
        self.pivot.center = (x, PIVOT_Y)
        self.ref.set_data([x, x], [PIVOT_Y, PIVOT_Y + POLE_LEN * 1.15])
        self.ref_label.set_position((x, PIVOT_Y + POLE_LEN * 1.15 + 0.03))

        deg = (math.degrees(th) + 180.0) % 360.0 - 180.0   # 0 = upright, 180 = down
        self.hud.set_text(
            f"time        {self.env.time[0]:6.2f} s\n"
            f"pole angle  {deg:+7.2f} deg\n"
            f"cart pos    {x:+6.3f} m\n"
            f"force       {self.env.last_force[0]:+6.2f} N")

    # ---------------- animation ----------------
    def _update(self, _frame):
        now = time.perf_counter()
        if self.t_start is None:
            self.t_start = now + START_DELAY
        if now >= self.t_start:
            target = now - self.t_start
            n = 0
            while self.env.time[0] < target and n < 6:   # keep sim in real time
                action = self.agent.act(self.obs, deterministic=True)
                self.obs = self.env.step(action)[0][0]
                n += 1
        self._draw()
        return self.artists

    def run(self):
        self._draw()
        self.anim = FuncAnimation(self.fig, self._update, interval=16,
                                  blit=True, cache_frame_data=False)
        plt.tight_layout()
        plt.show()
