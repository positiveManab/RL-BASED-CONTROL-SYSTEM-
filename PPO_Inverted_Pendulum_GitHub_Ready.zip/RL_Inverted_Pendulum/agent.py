"""PPO agent (PyTorch). Run `python agent.py` to retrain from scratch."""
import time
import numpy as np
import torch
import torch.nn as nn
import config as C


class ActorCritic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden):
        super().__init__()
        self.actor = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, act_dim))
        self.critic = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1))
        self.log_std = nn.Parameter(torch.full((act_dim,), -0.5))

    def dist(self, obs):
        return torch.distributions.Normal(self.actor(obs), self.log_std.exp())

    def value(self, obs):
        return self.critic(obs).squeeze(-1)


class PPOAgent:
    def __init__(self, obs_dim=5, act_dim=1, hidden=C.HIDDEN_SIZE):
        self.obs_dim, self.act_dim, self.hidden = obs_dim, act_dim, hidden
        self.net = ActorCritic(obs_dim, act_dim, hidden)
        self.opt = torch.optim.Adam(self.net.parameters(), lr=C.LEARNING_RATE)

    # ---------- inference ----------
    @torch.no_grad()
    def act(self, obs, deterministic=True):
        """Returns action in [-1, 1] (numpy)."""
        o = torch.as_tensor(obs, dtype=torch.float32)
        d = self.net.dist(o)
        a = d.mean if deterministic else d.sample()
        return np.clip(a.numpy(), -1.0, 1.0)

    # ---------- save / load ----------
    def save(self, path):
        torch.save({"state_dict": self.net.state_dict(), "obs_dim": self.obs_dim,
                    "act_dim": self.act_dim, "hidden": self.hidden}, path)

    @classmethod
    def load(cls, path):
        ckpt = torch.load(path, map_location="cpu", weights_only=True)
        agent = cls(ckpt["obs_dim"], ckpt["act_dim"], ckpt["hidden"])
        agent.net.load_state_dict(ckpt["state_dict"])
        agent.net.eval()
        return agent

    # ---------- PPO update ----------
    def update(self, b):
        obs, act, old_logp, adv, ret = b["obs"], b["act"], b["logp"], b["adv"], b["ret"]
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        n = obs.shape[0]
        for _ in range(C.PPO_EPOCHS):
            idx = torch.randperm(n)
            for i in range(0, n, C.MINIBATCH_SIZE):
                j = idx[i:i + C.MINIBATCH_SIZE]
                d = self.net.dist(obs[j])
                logp = d.log_prob(act[j]).sum(-1)
                ratio = (logp - old_logp[j]).exp()
                s1 = ratio * adv[j]
                s2 = ratio.clamp(1 - C.CLIP_EPS, 1 + C.CLIP_EPS) * adv[j]
                policy_loss = -torch.min(s1, s2).mean()
                value_loss = (self.net.value(obs[j]) - ret[j]).pow(2).mean()
                loss = (policy_loss + C.VALUE_COEF * value_loss
                        - C.ENTROPY_COEF * d.entropy().sum(-1).mean())
                self.opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), C.MAX_GRAD_NORM)
                self.opt.step()


def train():
    from environment import CartPoleEnv, wrap_angle
    torch.set_num_threads(1)
    torch.manual_seed(C.SEED)
    np.random.seed(C.SEED)
    n, T = C.NUM_ENVS, C.ROLLOUT_STEPS
    env = CartPoleEnv(num_envs=n, seed=C.SEED)
    agent = PPOAgent()
    obs = env.reset()
    t0 = time.time()

    for update in range(1, C.TOTAL_UPDATES + 1):
        frac = 1.0 - (update - 1) / C.TOTAL_UPDATES
        for g in agent.opt.param_groups:
            g["lr"] = C.LEARNING_RATE * (0.1 + 0.9 * frac)

        O = np.zeros((T, n, 5), np.float32); A = np.zeros((T, n, 1), np.float32)
        LP = np.zeros((T, n), np.float32); R = np.zeros((T, n), np.float32)
        V = np.zeros((T + 1, n), np.float32); END = np.zeros((T, n), np.float32)
        for t in range(T):
            o = torch.as_tensor(obs)
            with torch.no_grad():
                d = agent.net.dist(o)
                a = d.sample()
                LP[t] = d.log_prob(a).sum(-1).numpy()
                V[t] = agent.net.value(o).numpy()
            O[t], A[t] = obs, a.numpy()
            obs, r, done = env.step(a.numpy())
            if done.any():       # bootstrap through time-limit truncation
                with torch.no_grad():
                    r[done] += C.GAMMA * \
                        agent.net.value(torch.as_tensor(obs[done])).numpy()
                obs = env.reset_idx(done)
            R[t], END[t] = r, done
        with torch.no_grad():
            V[T] = agent.net.value(torch.as_tensor(obs)).numpy()

        # GAE
        adv = np.zeros((T, n), np.float32); last = np.zeros(n, np.float32)
        for t in reversed(range(T)):
            nonterm = 1.0 - END[t]
            delta = R[t] + C.GAMMA * V[t + 1] * nonterm - V[t]
            last = delta + C.GAMMA * C.GAE_LAMBDA * nonterm * last
            adv[t] = last
        ret = adv + V[:T]

        flat = lambda x: torch.as_tensor(x.reshape(T * n, *x.shape[2:]))
        agent.update({"obs": flat(O), "act": flat(A), "logp": flat(LP),
                      "adv": flat(adv), "ret": flat(ret)})

        upright = np.mean(np.abs(wrap_angle(env.state[:, 2])) < 0.2)
        print(f"update {update:3d}/{C.TOTAL_UPDATES}  mean reward/step "
              f"{R.mean() / C.REWARD_SCALE:6.3f}  upright {upright * 100:5.1f}%  "
              f"({time.time() - t0:.0f}s)", flush=True)
        if update % 25 == 0:
            agent.save(C.MODEL_PATH)

    agent.save(C.MODEL_PATH)
    print("Saved", C.MODEL_PATH)


if __name__ == "__main__":
    train()
